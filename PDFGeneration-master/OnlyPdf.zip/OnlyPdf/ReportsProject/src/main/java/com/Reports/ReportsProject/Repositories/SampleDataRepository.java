package com.Reports.ReportsProject.Repositories;

import com.Reports.ReportsProject.Entities.SampleData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SampleDataRepository extends JpaRepository<SampleData, Long> {

}
